import React, { useState } from 'react';
import { useBrain } from '../context/BrainContext';
import {
  Terminal,
  X,
  Copy,
  Check,
  ShieldCheck,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Cpu,
  Key,
  Server,
  Lock
} from 'lucide-react';

export const McpConfigModal: React.FC = () => {
  const {
    selectedMcpSlot,
    setSelectedMcpSlot,
    supabaseStatus,
    verifyMcpConnection,
    registerAccountInSupabase,
    session,
    user,
    setIsAuthModalOpen,
  } = useBrain();

  const [copied, setCopied] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null);

  if (!selectedMcpSlot) return null;

  const endpointUrl = `${(supabaseStatus.url || 'https://your-supabase-project.supabase.co').replace(/\/$/, '')}/functions/v1/ai-brain-api`;

  // Real authenticated session token or prompt to use anon key / login
  const authTokenValue = session?.access_token || 'PASTE_YOUR_SUPABASE_BEARER_TOKEN_HERE';

  const mcpConfigJson = JSON.stringify(
    {
      mcpServers: {
        mooderia_ai_brain: {
          command: "npx",
          args: ["-y", "@mooderia/ai-brain-mcp"],
          env: {
            SUPABASE_URL: supabaseStatus.url || "https://your-supabase-project.supabase.co",
            AI_BRAIN_ENDPOINT: endpointUrl,
            BRAIN_ACCOUNT_NAME: selectedMcpSlot.account_name,
            AUTH_BEARER_TOKEN: authTokenValue,
          },
        },
      },
    },
    null,
    2
  );

  const handleCopy = () => {
    navigator.clipboard.writeText(mcpConfigJson);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTestHandshake = async () => {
    setIsVerifying(true);
    setFeedback(null);
    const res = await verifyMcpConnection(selectedMcpSlot.slot_number);
    setIsVerifying(false);
    setFeedback({ ok: res.ok, message: res.message });
  };

  const handleRegisterAccount = async () => {
    if (!user) {
      setFeedback({ ok: false, message: 'Please sign in with your Main Owner account first to register accounts in Supabase.' });
      return;
    }

    setIsRegistering(true);
    setFeedback(null);
    const res = await registerAccountInSupabase(selectedMcpSlot.slot_number);
    setIsRegistering(false);
    if (res.success) {
      setFeedback({ ok: true, message: `Account "${selectedMcpSlot.account_name}" registered in Supabase via register_brain_account!` });
    } else {
      setFeedback({ ok: false, message: res.error || 'Registration failed' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl bg-white rounded-3xl sm:rounded-4xl shadow-2xl border border-purple-100 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-900 via-purple-800 to-indigo-900 text-white p-5 sm:p-6 relative">
          <button
            onClick={() => setSelectedMcpSlot(null)}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-1.5">
            <span className="p-1.5 rounded-xl bg-white/15 backdrop-blur-xs text-white">
              <Terminal className="w-5 h-5" />
            </span>
            <span className="text-xs font-bold tracking-widest uppercase text-purple-200">
              REMOTE MCP BRIDGE • SLOT #{selectedMcpSlot.slot_number}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black italic tracking-tight font-display">
            {selectedMcpSlot.account_name.toUpperCase()}
          </h2>
          <p className="text-xs text-purple-200/90 mt-0.5">
            {selectedMcpSlot.identity_label}
          </p>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span
              className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full inline-flex items-center gap-1.5 ${
                selectedMcpSlot.is_registered_in_db
                  ? 'bg-emerald-400/20 text-emerald-300 border border-emerald-400/40'
                  : 'bg-white/10 text-purple-200 border border-white/20'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  selectedMcpSlot.is_registered_in_db ? 'bg-emerald-400' : 'bg-slate-400'
                }`}
              />
              {selectedMcpSlot.is_registered_in_db ? 'Registered in DB' : 'Not Registered'}
            </span>

            <span
              className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full inline-flex items-center gap-1.5 ${
                selectedMcpSlot.mcp_connection_state === 'connected'
                  ? 'bg-emerald-400/20 text-emerald-300 border border-emerald-400/40'
                  : 'bg-amber-400/20 text-amber-300 border border-amber-400/40'
              }`}
            >
              {selectedMcpSlot.mcp_connection_state === 'connected' ? 'MCP Live Handshake OK' : 'Awaiting Claude Client Connection'}
            </span>
          </div>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4">
          {/* Identity Protection Notice */}
          <div className="p-3.5 rounded-2xl bg-purple-50 border border-purple-100 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-purple-700 shrink-0 mt-0.5" />
            <div className="text-xs text-purple-900 leading-snug">
              <p className="font-bold">Protected Account Identity & Real Authentication</p>
              <p className="text-[11px] text-purple-700 mt-0.5">
                No simulated or fake tokens. Claude authenticates to your Supabase Edge Function (<code>ai-brain-api</code>) using your authenticated session Bearer token. Database registration calls <code>register_brain_account(p_auth_user_id, p_account_name, p_provider)</code>.
              </p>
            </div>
          </div>

          {/* Edge Function Endpoint */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700">
              Supabase Edge Function Endpoint (ai-brain-api)
            </label>
            <div className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono-code text-slate-800 break-all select-all">
              <Server className="w-4 h-4 text-purple-600 shrink-0" />
              <span>{endpointUrl}</span>
            </div>
          </div>

          {/* MCP Configuration snippet for Claude Desktop */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700">
                Claude Desktop Configuration (<code>claude_desktop_config.json</code>)
              </label>
              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-1 text-xs font-bold text-purple-700 hover:text-purple-900 cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Copied JSON</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Config</span>
                  </>
                )}
              </button>
            </div>

            <pre className="p-3 bg-slate-900 text-slate-100 rounded-2xl text-[11px] font-mono-code overflow-x-auto border border-slate-800">
              {mcpConfigJson}
            </pre>

            {!session && (
              <p className="text-[10px] text-amber-700 flex items-center gap-1 mt-1">
                <Lock className="w-3 h-3" />
                <span>You are not signed in. Sign in to automatically populate the real session JWT Bearer token above.</span>
              </p>
            )}
          </div>

          {/* Feedback status */}
          {feedback && (
            <div
              className={`p-3 rounded-xl text-xs font-medium flex items-center gap-2 ${
                feedback.ok
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-amber-50 text-amber-900 border border-amber-200'
              }`}
            >
              {feedback.ok ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              )}
              <span>{feedback.message}</span>
            </div>
          )}

          {/* Actions */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
            {!selectedMcpSlot.is_registered_in_db && (
              <button
                onClick={handleRegisterAccount}
                disabled={isRegistering}
                className="w-full sm:flex-1 py-2.5 px-4 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-md shadow-purple-900/10 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
                title="Calls register_brain_account(p_auth_user_id, p_account_name, p_provider)"
              >
                {isRegistering ? 'Registering Account...' : 'Register in Supabase'}
              </button>
            )}

            <button
              onClick={handleTestHandshake}
              disabled={isVerifying}
              className={`w-full ${selectedMcpSlot.is_registered_in_db ? 'sm:flex-1 bg-purple-700 hover:bg-purple-800 text-white' : 'sm:w-auto bg-slate-100 hover:bg-slate-200 text-slate-800'} py-2.5 px-4 rounded-xl font-bold text-xs transition-colors cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isVerifying ? 'animate-spin' : ''}`} />
              <span>{isVerifying ? 'Testing Handshake...' : 'Verify MCP Handshake'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
